import jinja2


ip_list = ['192.168.11.1', '192.178.11.1', '11.11.11.1']

jinja_env = jinja2.Environment(loader=jinja2.FileSystemLoader('templates'))

jinja_temp_var = {'ip_list': ip_list}

jinja_temp = jinja_env.get_template('bgp_config.j2')

rendered_temp = jinja_temp.render(jinja_temp_var)

print(rendered_temp)

print(type(rendered_temp))
