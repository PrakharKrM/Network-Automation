'''
Netmiko Link :- https://pynet.twb-tech.com/blog/netmiko-python-library.html
				https://ktbyers.github.io/netmiko/docs/netmiko/base_connection.html#netmiko.base_connection.BaseConnection

pyats_genie_command_parse Link:-  https://pyats-genie-command-parse.readthedocs.io/en/latest/doc-source/pyats_genie_command_parse/pyats_genie_command_parse.html#pyats_genie_command_parse.pyats_genie_command_parse.GenieCommandParse.parse_file

jinja link:- https://jinja.palletsprojects.com/en/3.1.x/api/

JSON link:- https://docs.python.org/3/library/json.html

Pyats Genie Command Parsers:- https://pubhub.devnetcloud.com/media/genie-feature-browser/docs/#/parsers

''' 

import netmiko  # Library used to established SSH connection with device 
import pyats_genie_command_parse  # Used to parse device output and get in dictionary format 
import json  # Used to convert into python object into JSON and vice versa
import jinja2 # used for templating 

device_details = { 'host' : '173.16.1.205' , 'username': 'admin', 'password': 'admin' , 'device_type': 'cisco_nxos'}  # To be used while connect to device

connect_device = netmiko.ConnectHandler(**device_details) # Establishing connection with device with device details inside device_details dict

sh_ver = connect_device.send_command('show version')  # Used to send "show version" command to device get output from device & store it into sh_Ver

genie_object = pyats_genie_command_parse.pyats_genie_command_parse.GenieCommandParse(nos='nxos')  # Crete genie object of pyats_genie_command_parse and define target network device OS. In my case device is Cisco NXOS that is why i used nxos.

parse_string_data = genie_object.parse_string(show_command='show version', show_output_data= sh_ver) # Used to parse string data and get into output in dictionary. Which can be processed further to use as per our requirements.

print("************"*6)
print(parse_string_data['platform']['hardware']['processor_board_id'])  # Parsed data in previous step are dictionary with key value pair. And we can access any value using keys of dictionary. 

with open(r'output/processed_sh_version.json', 'w') as JF:  # Open file to write data into file
	json.dump(parse_string_data, JF, indent=4)  # Write data into file as json format

JINJA_ENVIRO = jinja2.Environment(loader=jinja2.FileSystemLoader('templates'))  # Create environment for template and define path where our jinja templates are stored

JINJA_VAR = { "ip_list": ['192.168.11.1', '8.8.90.1', '11.11.11.1'] }  # Variable for jinja templates. These variable looked by template while rendering/creating templates

Template_format = JINJA_ENVIRO.get_template('bgp_config.j2')  # Selecting templates from available templates inside templates directly which we gave in line 36

RENDER_TEMP = Template_format.render(JINJA_VAR)  # Create template by using variables and get final template which can be used to configure devices

print(RENDER_TEMP)  # Priting created template

connect_device.send_config_set(config_commands= RENDER_TEMP)  # Configuring device with created templates 

#with open(r'output/precheck.txt', 'w' ) as file1:
#	for k in command_list:
#		sh_output = connect_device.send_command(k.strip(''))
#		file1.write(sh_output)

connect_device.disconnect()  # Disconnect SSH connection with device
