#/usr/bin/environment python
import netmiko 
import pyats_genie_command_parse 
import json

device_details = { 'host': '173.16.1.204', 'username': 'admin', 'password': 'admin', 'device_type': 'cisco_nxos'}

connected_Device = netmiko.ConnectHandler(**device_details)
show_ver_output = connected_Device.send_command('show version')
with open(r'output/show_Version.txt', 'w') as file:
	file.write(show_ver_output)

parse_object = pyats_genie_command_parse.pyats_genie_command_parse.GenieCommandParse(nos='nxos')

parsed_output_string = parse_object.parse_string(show_command='show version', show_output_data= show_ver_output)
parse_output_file = parse_object.parse_file(show_command="show version", file_name_and_path= r'output/show_Version.txt')
print("From parse string result \n " + str(parsed_output_string) + "\n *********************")
print("from parse file result \n" + str(parse_output_file) +"\n********************")

with open(r"output/parsed_data.json", 'w') as parse_file:
	json.dump(parse_output_file, parse_file, indent= 4)
